
# Passos

[*] Executar o programa passando o nome do arquivo a ser lido como argumento

[*] Abrir o arquivo usando o nome passado pelo comando

[*] Ler a primeira linha do arquivo e salvar

[*] Ler a próxima linha

[ ] Chamar o programa em Fortran e passar o par de strings

[*] Procurar uma ocorrência da primeira string, incrementar o contador caso encontre ocorrência

[*] Repetir o passo 6 até verificar a linha inteira

[*] Repetir os passos 4, 5, 6 e 7 até o fim do arquivo

[*] Imprimir o contador de ocorrências na tela